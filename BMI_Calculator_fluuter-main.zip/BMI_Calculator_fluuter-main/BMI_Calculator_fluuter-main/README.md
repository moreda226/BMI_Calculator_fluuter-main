# BMI Calculator

A simple Body Mass Index calculator app that includes interactive elements for selecting gender,
and adjusting height, weight, and age. Users can calculate their BMI by pressing the "CALCULATE" button,
which navigates to another screen displaying the result.


![Screen Shot 2023-10-29 at 8 15 22 PM](https://github.com/MostafaRadian/BMI_Calculator_fluuter/assets/46004434/937b7183-9e04-4963-a29a-49de952193ca) ![Screen Shot 2023-10-29 at 8 15 48 PM](https://github.com/MostafaRadian/BMI_Calculator_fluuter/assets/46004434/bdf0f0e6-e41d-43a1-8e36-6da2803abb04)
